<br/>
<div style="width:100%;height:50px;background-color:skyblue;line-height:50px;float:left;">
		© 2015 MK Magazine
</div>