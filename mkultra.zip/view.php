<?php 
	
	if(isset($_GET['mode'])){
		$mode=$_GET['mode']=='1'?true:false;
	}
	else{
		$mode=false;
	}
	
	if($mode){
		
	}
	else{
		
	}
	
	
	
	
	
	
?>